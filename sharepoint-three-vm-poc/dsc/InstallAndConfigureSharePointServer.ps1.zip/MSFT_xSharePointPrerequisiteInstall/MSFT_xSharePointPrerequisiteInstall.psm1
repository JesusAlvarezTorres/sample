Import-LocalizedData LocalizedData -filename MSFT_xSharePointPrerequisiteInstall.strings.psd1
Import-Module $PSScriptRoot\..\..\xPDT.psm1

#region GET
function Get-TargetResource 
{
    [CmdletBinding()]
     param
    (
        [Parameter(Mandatory=$true)]
        [String]
        $SourcePath,

        [String]
        $SourceFolder,
        
        [Parameter(Mandatory=$true)]
        [PSCredential]
        $Credential
    )
        
	return @{
		SourcePath = $SourcePath
        SourceFolder = $SourceFolder
		Credential = $Credential
        MicrosoftSQLServer2008R2SP1NativeClient = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\Microsoft SQL Server\SQLNCLI10\CurrentVersion' -ErrorAction SilentlyContinue).Version
        MicrosoftSyncFrameworkRuntimev10SP1x64 = (Get-ItemProperty -Path 'C:\Windows\assembly\GAC_MSIL\Microsoft.Synchronization\1.0.0.0__89845dc8080cc91\Microsoft.Synchronization.dll' -ErrorAction SilentlyContinue).VersionInfo.FileVersion
        WindowsServerAppFabric = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\AppFabric\V1.0' -ErrorAction SilentlyContinue).ProductVersion
        CumulativeUpdatePackage1forMicrosoftAppFabric11forWindowsServerKB2671763 = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Wow6432Node\Microsoft\Updates\AppFabric 1.1 for Windows Server\KB2671763' -ErrorAction SilentlyContinue).IsInstalled -ne $null
        WindowsIdentityFoundation = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\Windows Identity Foundation\Setup\v3.5' -ErrorAction SilentlyContinue).'(default)'
        MicrosoftIdentityExtensions = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\Microsoft Identity Extensions\Setup\1.0' -ErrorAction SilentlyContinue) -ne $null
        MicrosoftInformationProtectionandControlClient = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\MSIPC\CurrentVersion' -ErrorAction SilentlyContinue).'(default)'
        MicrosoftWCFDataServices50 = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Wow6432Node\Microsoft\Microsoft WCF Data Services\5.0' -ErrorAction SilentlyContinue).Version
        MicrosoftWCFDataServices56 = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Wow6432Node\Microsoft\Microsoft WCF Data Services\5.6' -ErrorAction SilentlyContinue).Version
		}
}
# Get-TargetResource -SourcePath 'F:' -SourceFolder 'SharePoint' -Credential (get-credential)
# Expectation is the function will return a hashtable with a boolean for Result to indicate whether the application is install and information about how the application was installed
#endregion

#region SET
function Set-TargetResource
{
    [CmdletBinding()]
     param
    (
        [Parameter(Mandatory=$true)]
        [String]
        $SourcePath,

        [String]
        $SourceFolder,
        
        [Parameter(Mandatory=$true)]
        [PSCredential]
        $Credential
    )

    $SourcePath = Join-Path -Path $SourcePath -ChildPath $SourceFolder
    $Installer = Join-Path -Path $SourcePath -ChildPath 'PrerequisiteInstaller.exe'
    $Installer = ResolvePath $Installer
    Write-Verbose "Installer: $Installer"

    $Arguments = "/Unattended /SQLNCli:$SourcePath\PrerequisiteInstallerFiles\sqlncli.msi /IDFX:$SourcePath\PrerequisiteInstallerFiles\Windows6.1-KB974405-x64.msu /IDFX11:$SourcePath\PrerequisiteInstallerFiles\MicrosoftIdentityExtensions-64.msi /Sync:$SourcePath\PrerequisiteInstallerFiles\Synchronization.msi /AppFabric:$SourcePath\PrerequisiteInstallerFiles\WindowsServerAppFabricSetup_x64.exe /KB2671763:$SourcePath\PrerequisiteInstallerFiles\AppFabric1.1-RTM-KB2671763-x64-ENU.exe /MSIPCClient:$SourcePath\PrerequisiteInstallerFiles\setup_msipc_x64.msi /WCFDataServices:$SourcePath\PrerequisiteInstallerFiles\WcfDataServices5.exe  /WCFDataServices56:$SourcePath\PrerequisiteInstallerFiles\WcfDataServices56.exe"
    Write-Verbose "Arguments: $Arguments"	

	$Process = StartWin32Process -Path $Installer -Arguments $Arguments -Credential $Credential
	Write-Verbose $Process
	WaitForWin32ProcessEnd -Path $Installer -Arguments $Arguments -Credential $Credential

    $Test = Test-TargetResource @PSBoundParameters

    if ($Test -eq $true) 
    {
        Write-Verbose 'Installation successful.  Reboot pending'
        $Global:DSCMachineStatus = 1
    }
    else
    {
        Throw 'The prerequisite installation failed'
    }

}
# Set-TargetResource -SourcePath 'F:' -SourceFolder 'SharePoint' -Credential (get-credential)
# Expectation is the application would be installed silently
#endregion

#region TEST
function Test-TargetResource 
{
    [CmdletBinding()]
     param
    (
        [Parameter(Mandatory=$true)]
        [String]
        $SourcePath,

        [String]
        $SourceFolder,
        
        [Parameter(Mandatory=$true)]
        [PSCredential]
        $Credential
    )
        
        $Return = $True

        #MicrosoftSQLServer2008R2SP1NativeClient
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\Microsoft SQL Server\SQLNCLI10\CurrentVersion' -ErrorAction SilentlyContinue).Version -eq '10.51.2500.0' -AND $Return -eq $True

        #MicrosoftSyncFrameworkRuntimev10SP1x64
        $Return = (Get-ItemProperty -Path 'C:\Windows\assembly\GAC_MSIL\Microsoft.Synchronization\1.0.0.0__89845dcd8080cc91\Microsoft.Synchronization.dll' -ErrorAction SilentlyContinue).VersionInfo.FileVersion -eq '1.0.3010.0' -AND $Return -eq $True

        #WindowsServerAppFabric
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\AppFabric\V1.0' -ErrorAction SilentlyContinue).ProductVersion -eq '1.1.2106.32' -AND $Return -eq $True
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\AppFabric\V1.0\Features' -ErrorAction SilentlyContinue).DCC -eq '1' -AND $Return -eq $True
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\AppFabric\V1.0\Features' -ErrorAction SilentlyContinue).DCS -eq '1' -AND $Return -eq $True
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\AppFabric\V1.0\Features' -ErrorAction SilentlyContinue).DCA -eq '1' -AND $Return -eq $True

        #CumulativeUpdatePackage1forMicrosoftAppFabric11forWindowsServerKB2671763
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Wow6432Node\Microsoft\Updates\AppFabric 1.1 for Windows Server\KB2671763' -ErrorAction SilentlyContinue).IsInstalled -ne $null -AND $Return -eq $True

        #WindowsIdentityFoundation
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\Windows Identity Foundation\Setup\v3.5' -ErrorAction SilentlyContinue).'(default)' -eq '6.1.7600.0' -AND $Return -eq $True

        #MicrosoftIdentityExtensions
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\Microsoft Identity Extensions\Setup\1.0' -ErrorAction SilentlyContinue) -ne $null -AND $Return -eq $True

        #MicrosoftInformationProtectionandControlClient
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Microsoft\MSIPC\CurrentVersion' -ErrorAction SilentlyContinue).'(default)' -eq '1.0.621.117' -AND $Return -eq $True

        #MicrosoftWCFDataServices50
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Wow6432Node\Microsoft\Microsoft WCF Data Services\5.0' -ErrorAction SilentlyContinue).Version -eq '5.0.51212.0' -AND $Return -eq $True

        #MicrosoftWCFDataServices56
        $Return = (Get-ItemProperty -Path 'HKLM:SOFTWARE\Wow6432Node\Microsoft\Microsoft WCF Data Services\5.6' -ErrorAction SilentlyContinue).Version -eq '5.6.61587.0' -AND $Return -eq $True

        return $Return

}
# Test-TargetResource -SourcePath 'F:' -SourceFolder 'SharePoint' -Credential (get-credential)
# Expectation is a boolean response based on whether the application is installed
#endregion

Export-ModuleMember -Function *-TargetResource